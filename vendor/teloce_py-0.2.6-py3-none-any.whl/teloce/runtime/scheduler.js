const pending = new Set();
const batched = new Set();
let scheduled = false;
let batchDepth = 0;

export function queueJob(job) {
  if (batchDepth) {
    batched.add(job);
    return;
  }
  pending.add(job);
  if (!scheduled) {
    scheduled = true;
    queueMicrotask(flushJobs);
  }
}

export function batch(fn) {
  batchDepth += 1;
  try {
    return fn();
  } finally {
    batchDepth -= 1;
    if (!batchDepth && batched.size) {
      for (const job of batched) pending.add(job);
      batched.clear();
      if (!scheduled) {
        scheduled = true;
        queueMicrotask(flushJobs);
      }
    }
  }
}

export function flushJobs() {
  scheduled = false;
  const jobs = [...pending];
  pending.clear();
  for (const job of jobs) job();
}
