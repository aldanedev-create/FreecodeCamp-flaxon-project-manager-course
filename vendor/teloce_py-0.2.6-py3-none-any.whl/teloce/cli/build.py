"""
Build command - builds for production.

Builds the project for production deployment.
"""

from typing import Any

from teloce.project.discovery import ProjectDiscovery
from teloce.project.configuration import ProjectConfiguration
from teloce.build.builder import Builder


def build_command(args: Any) -> int:
    """
    Build for production.
    
    Args:
        args: Command-line arguments.
        
    Returns:
        Exit code.
    """
    print("📦 Teloce Build")
    print("=" * 40)
    
    # Discover project
    discovery = ProjectDiscovery()
    discovery.discover()
    
    print(f"📁 Project: {discovery.get_project_name()}")
    
    # Load configuration
    config = ProjectConfiguration()
    config.load(discovery.config_file)
    
    # Get build config
    build_config = config.get_build_config()
    out_dir = args.out_dir if args.out_dir is not None else build_config.get('out_dir', 'dist')
    minify = args.minify or (not args.no_minify and build_config.get('minify', False))
    compiler_config = config.get_compiler_config()
    source_map = args.source_map or compiler_config.get('source_maps', build_config.get('source_maps', False))
    clean = not getattr(args, 'no_clean', False) and build_config.get('clean', True)
    if getattr(args, 'direct_dom_updates', False):
        direct_dom_updates = True
    elif getattr(args, 'no_direct_dom_updates', False):
        direct_dom_updates = False
    else:
        direct_dom_updates = build_config.get('direct_dom_updates', False)
    strict_dependency_analysis = (
        getattr(args, 'strict_dependency_analysis', False)
        or build_config.get('strict_dependency_analysis', False)
    )
    
    print(f"📂 Output: {out_dir}")
    print(f"⚡ Minify: {'Yes' if minify else 'No'}")
    print(f"🗺️  Source Maps: {'Yes' if source_map else 'No'}")
    print(f"🎯 Direct DOM updates: {'Yes' if direct_dom_updates else 'No'}")
    print()
    
    # Build
    static_mode = bool(getattr(args, 'static', False) or build_config.get('static', False))
    if getattr(args, 'spa', False):
        spa = True
    elif getattr(args, 'no_spa', False):
        spa = False
    else:
        spa = build_config.get('spa', 'auto')

    builder = Builder({
        'mode': 'production',
        'production': True,
        'minify': minify,
        'source_maps': source_map,
        'dev': False,
        'clean': clean,
        'static_dir': build_config.get('static_dir', 'static'),
        'html_mode': build_config.get('html_mode', False),
        'jobs': (args.jobs if getattr(args, 'jobs', None) is not None else build_config.get('jobs', 1)),
        'source_extensions': build_config.get('source_extensions'),
        'source_roots': build_config.get('source_roots'),
        'hash_assets': (not getattr(args, 'no_hash_assets', False)
                        and (getattr(args, 'hash_assets', False)
                             or build_config.get('hash_assets', True))),
        'extract_css': not getattr(args, 'no_extract_css', False) and build_config.get('extract_css', True),
        'css_bundle': build_config.get('css_bundle', True),
        'embed': build_config.get('embed', {'enabled': False}),
        'bundle': getattr(args, 'bundle', False) or build_config.get('bundle', False),
        'bundler': getattr(args, 'bundler', None) or build_config.get('bundler', 'minifyjs'),
        'minifier': getattr(args, 'minifier', None) or build_config.get('minifier', 'minifyjs'),
        'code_splitting': not getattr(args, 'no_splitting', False) and build_config.get('code_splitting', True),
        'target': build_config.get('target', compiler_config.get('target', 'es2020')),
        'charset': build_config.get('charset', 'utf8'),
        'external': build_config.get('external', []),
        'packages': build_config.get('packages', 'bundle'),
        'define': build_config.get('define', {}),
        'drop': build_config.get('drop', []),
        'bundle_entry': getattr(args, 'entry', None) or build_config.get('bundle_entry'),
        'bundle_output': build_config.get('bundle_output'),
        'report': getattr(args, 'report', None) or build_config.get('report'),
        'max_asset_size': getattr(args, 'max_size', 0) or build_config.get('max_asset_size', 0),
        'ssr': getattr(args, 'ssr', False) or build_config.get('ssr', False) or static_mode,
        'static': static_mode,
        'shared_runtime': build_config.get('shared_runtime', True),
        'direct_dom_updates': direct_dom_updates,
        'strict_dependency_analysis': strict_dependency_analysis,
        'lazy_components': ([item.strip() for item in args.lazy_components.split(',') if item.strip()]
                            if getattr(args, 'lazy_components', None) is not None
                            else build_config.get('lazy_components', [])),
        'tree_shake': not getattr(args, 'no_tree_shake', False) and build_config.get('tree_shake', True),
        'spa': spa,
        'spa_mode': build_config.get('spa_mode', 'hash'),
        'spa_base': build_config.get('spa_base', '/'),
        'spa_pages': build_config.get('spa_pages'),
        'spa_router': build_config.get('spa_router'),
        'spa_routes': build_config.get('spa_routes', {}),
    })
    
    result = builder.build(discovery.root_dir, out_dir)
    
    # Print results
    print("✅ Build complete!")
    print()
    print("📊 Statistics:")
    print(f"   Total files: {result['total']}")
    print(f"   Compiled: {result['compiled']}")
    print(f"   Failed: {result['failed']}")
    print(f"   Assets copied: {result.get('assets_copied', 0)}")
    print(f"   Generated bytes: {result.get('total_bytes', 0)}")
    if result.get('report'):
        print(f"   Report: {result['report']}")
    for warning in result.get('size_warnings', []):
        print(f"   ⚠️  {warning['output']}: {warning['message']}")
    print(f"   Duration: {result['duration']:.2f}s")
    
    if result['errors']:
        print()
        print("❌ Errors:")
        for error in result['errors']:
            print(f"   {error['file']}: {error['error']}")
        return 1
    
    return 0
